﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Hangman
{
    public partial class Form1 : Form
    {

        PictureBox[] pictureBoxList = new PictureBox[100];

        public Form1()
        {
            InitializeComponent();
            pictureBoxList[0] = pictureBox0;
            pictureBoxList[1] = pictureBox1;
            pictureBoxList[2] = pictureBox2;
            pictureBoxList[3] = pictureBox3;
            pictureBoxList[4] = pictureBox4;
            pictureBoxList[5] = pictureBox5;
            pictureBoxList[6] = pictureBox6;
            pictureBoxList[7] = pictureBox7;
            pictureBoxList[8] = pictureBox8;
            pictureBoxList[9] = pictureBox9;
            pictureBoxList[10] = pictureBox10;
            pictureBoxList[11] = pictureBox11;
            pictureBoxList[12] = pictureBox12;
            pictureBoxList[13] = pictureBox13;
            pictureBoxList[14] = pictureBox14;
            pictureBoxList[15] = pictureBox15;
            pictureBoxList[16] = pictureBox16;
            pictureBoxList[17] = pictureBox17;
            pictureBoxList[18] = pictureBox18;
            pictureBoxList[19] = pictureBox19;
            pictureBoxList[20] = pictureBox20;
            pictureBoxList[21] = pictureBox21;
            pictureBoxList[22] = pictureBox22;
            pictureBoxList[23] = pictureBox23;
            pictureBoxList[24] = pictureBox24;
            pictureBoxList[25] = pictureBox25;
            pictureBoxList[26] = pictureBox26;
            pictureBoxList[27] = pictureBox27;
            pictureBoxList[28] = pictureBox28;
            pictureBoxList[29] = pictureBox29;
            pictureBoxList[30] = pictureBox30;
            pictureBoxList[31] = pictureBox31;
            pictureBoxList[32] = pictureBox32;
            pictureBoxList[33] = pictureBox33;
            pictureBoxList[34] = pictureBox34;
            pictureBoxList[35] = pictureBox35;
            pictureBoxList[36] = pictureBox36;
            pictureBoxList[37] = pictureBox37;
            pictureBoxList[38] = pictureBox38;
            pictureBoxList[39] = pictureBox39;
            pictureBoxList[40] = pictureBox40;
            pictureBoxList[41] = pictureBox41;
            pictureBoxList[42] = pictureBox42;
            pictureBoxList[43] = pictureBox43;
            pictureBoxList[44] = pictureBox44;
            pictureBoxList[45] = pictureBox45;
            pictureBoxList[46] = pictureBox46;
            pictureBoxList[47] = pictureBox47;
            pictureBoxList[48] = pictureBox48;
            pictureBoxList[49] = pictureBox49;
            pictureBoxList[50] = pictureBox50;
            pictureBoxList[51] = pictureBox51;
            pictureBoxList[52] = pictureBox52;
            pictureBoxList[53] = pictureBox53;
            pictureBoxList[54] = pictureBox54;
            pictureBoxList[55] = pictureBox55;
            pictureBoxList[56] = pictureBox56;
            pictureBoxList[57] = pictureBox57;
            pictureBoxList[58] = pictureBox58;
            pictureBoxList[59] = pictureBox59;
            pictureBoxList[60] = pictureBox60;
            pictureBoxList[61] = pictureBox61;
            pictureBoxList[62] = pictureBox62;
            pictureBoxList[63] = pictureBox63;
            pictureBoxList[64] = pictureBox64;
            pictureBoxList[65] = pictureBox65;
            pictureBoxList[66] = pictureBox66;
            pictureBoxList[67] = pictureBox67;
            pictureBoxList[68] = pictureBox68;
            pictureBoxList[69] = pictureBox69;
            pictureBoxList[70] = pictureBox70;
            pictureBoxList[71] = pictureBox71;
            pictureBoxList[72] = pictureBox72;
            pictureBoxList[73] = pictureBox73;
            pictureBoxList[74] = pictureBox74;
            pictureBoxList[75] = pictureBox75;
            pictureBoxList[76] = pictureBox76;
            pictureBoxList[77] = pictureBox77;
            pictureBoxList[78] = pictureBox78;
            pictureBoxList[79] = pictureBox79;
            pictureBoxList[80] = pictureBox80;
            pictureBoxList[81] = pictureBox81;
            pictureBoxList[82] = pictureBox82;
            pictureBoxList[83] = pictureBox83;
            pictureBoxList[84] = pictureBox84;
            pictureBoxList[85] = pictureBox85;
            pictureBoxList[86] = pictureBox86;
            pictureBoxList[87] = pictureBox87;
            pictureBoxList[88] = pictureBox88;
            pictureBoxList[89] = pictureBox89;
            pictureBoxList[90] = pictureBox90;
            pictureBoxList[91] = pictureBox91;
            pictureBoxList[92] = pictureBox92;
            pictureBoxList[93] = pictureBox93;
            pictureBoxList[94] = pictureBox94;
            pictureBoxList[95] = pictureBox95;
            pictureBoxList[96] = pictureBox96;
            pictureBoxList[97] = pictureBox97;
            pictureBoxList[98] = pictureBox98;
            pictureBoxList[99] = pictureBox99;

        }
        List<int> AllowedPictureBoxes = new List<int>();

        string[] DirectionList = { "HigherLeft", "Up", "HigherRight", "Left", "LowerRight", "Down", "LowerLeft", "Right" };
        int[] DirectionAmountList = { -11, -10, -9, -1, 11, 10, 9, 1 };
        int[] DirectionSwapper = { 4, 5, 6, 7, 0, 1, 2, 3 };
        List<string> DirectionsNotBanned = new List<string>();
        int CountToNewDirection = 0;

        string direction = "";
        int DirectionDecider = 0;
        int directionAmount = 0;
        int wordLimitReset = 0;
        

        int Length = 0; //always the length of the word in use
        int x = 0;
        int y = 0; //for when x isnt available
        int loopsDone = 0; //used to loop the process of choosing a direction, letter positions and checking if they're valid. If the pictureBoxesPath is wrong this turns to 0 or less.
         
        string[] Letters = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };
        string Input = "";
        List<string> InputList = new List<string>();

        
        
        List<char> ChoppedUpWord = new List<char>();
        Random rnd = new Random();
        List<int> pictureBoxesLeft = new List<int>();

        List<int> pictureBoxesPath = new List<int>();

        int InputsLeft = 0;
        int InputsLoaded = 0;
        int PictureBoxesToAdd = 0;



        private void button1_Click(object sender, EventArgs e)
        {
            //clearing everything and reseting it
            wordLimitReset = 0;

            DirectionsNotBanned.Clear();
            while (x < 8)
            {
                DirectionsNotBanned.Add(DirectionList[x]);
                x += 1;
            }
            x = 0;

            pictureBoxesLeft.Clear();
            PictureBoxesToAdd = 0;
            while (PictureBoxesToAdd < 100)
            {
                pictureBoxesLeft.Add(PictureBoxesToAdd);
                PictureBoxesToAdd += 1;
            }

            int PictureBoxPosition = rnd.Next(100);
            int Start = PictureBoxPosition;

            int CounterTo100 = 0;
            while (CounterTo100 < 100)
            {
                if (pictureBoxesLeft.Contains(CounterTo100))
                {


                    pictureBoxList[CounterTo100].SizeMode = PictureBoxSizeMode.StretchImage;
                    string DisplayedLetter = Letters[rnd.Next(0, 25)];
                    pictureBoxList[CounterTo100].Load(DisplayedLetter + ".png"); //filling all 100 picture boxes with any random letter to be written over when words are being placed.
                }


                CounterTo100 += 1;


            }



            InputsLoaded = 0;
            while (InputsLeft > 0) //loops until every word in InputList is added to the wordsearch.
            {

                //cleaning variables.
                ChoppedUpWord.Clear();
                loopsDone = 0;
                
                x = 0;
                //


                //turning the current word into a list.
                string TheWord = InputList[InputsLoaded]; //InputsLoaded starts as 0 and increases as InputsLeft decreases at the end of a "while(Length > loopsDone)" loop.
                Length = TheWord.Length; 
                while (x < Length) //count starts at 0 like a list but length counted the first letter as 1, 2 etc. Thats why its never use when equal to Length.
                {

                    ChoppedUpWord.Add(TheWord[x]); //adding every letter of the word to a list. 
                    x += 1;
                }
                //
                x = 0;

                CountToNewDirection = 3;

                while (Length > loopsDone) //ends once a word is placed onto the wordsearch.
                {
                    loopsDone = Length; //loopsDone never increases other than here. It only decreases
                    if (CountToNewDirection == 3)
                    {
                        DirectionDecider = (rnd.Next(DirectionsNotBanned.Count)); //random but important position in list.
                        direction = DirectionsNotBanned[DirectionDecider];

                        directionAmount = DirectionAmountList[Array.IndexOf(DirectionList, direction)]; //the lists direction and directionAmount are always parallel for this to work.


                    }
                    
                    AllowedPictureBoxes.Clear();
                    x = 0;
                    while (x < pictureBoxesLeft.Count) //depending on the direction positions for the initial letter to choose from are limited to only valid ones.
                    {
                        int FirstDigit = pictureBoxesLeft[x] / 10;
                        int SecondDigit = pictureBoxesLeft[x] % 10; 

                        if (direction == "LowerRight")
                        {
                            if (FirstDigit < (11 - Length) & SecondDigit < (11 - Length)) 
                            { AllowedPictureBoxes.Add(pictureBoxesLeft[x]); }
                        }
                        if (direction == "HigherRight")
                        {
                            if (FirstDigit > (Length - 2) & SecondDigit < (11 - Length))
                            { AllowedPictureBoxes.Add(pictureBoxesLeft[x]); }

                        }
                        if (direction == "LowerLeft")
                        {
                            if (FirstDigit < (11 - Length) & SecondDigit > (Length - 2))
                            { AllowedPictureBoxes.Add(pictureBoxesLeft[x]); }
                        }
                        if (direction == "HigherLeft")
                        {
                            if (FirstDigit > (Length - 2) & SecondDigit > (Length - 2))
                            { AllowedPictureBoxes.Add(pictureBoxesLeft[x]); }
                        }
                        if (direction == "Down")
                        {
                            if (FirstDigit < (11 - Length))
                            { AllowedPictureBoxes.Add(pictureBoxesLeft[x]); }
                        }
                        if (direction == "Up")
                        {
                            if (FirstDigit > (Length - 2))
                            { AllowedPictureBoxes.Add(pictureBoxesLeft[x]); }
                        }
                        if (direction == "Right")
                        {
                            if (SecondDigit < (11 - Length))
                            { AllowedPictureBoxes.Add(pictureBoxesLeft[x]); }
                        }
                        if (direction == "Left")
                        {
                            if (SecondDigit > (Length - 2))
                            { AllowedPictureBoxes.Add(pictureBoxesLeft[x]); }
                        }
                        y = 1;
                        while (y < Length)
                        {
                            if (pictureBoxesLeft.Contains(pictureBoxesLeft[x] + (y * directionAmount))) //checks picture boxes within the path to see if they aren't already filled
                            { y += 1; }
                            else
                            {
                                AllowedPictureBoxes.Remove(pictureBoxesLeft[x]);
                                y = Length;
                            }
                            
                        }
                        
                        x += 1;

                    }
                    x = 0;
                    PictureBoxPosition = rnd.Next(AllowedPictureBoxes.Count - 1);
                    PictureBoxPosition = AllowedPictureBoxes[PictureBoxPosition];

                    pictureBoxesPath.Clear();
                    
                    while (Length > x)
                    {
                        pictureBoxesPath.Add(PictureBoxPosition);
                        PictureBoxPosition += directionAmount;
                        x += 1;
                    }
                    
                    x = 0;
                    int PrevEdgeCheck = 0;
                    int EdgeCheck = 0;  //If the direction is diagonal then the pictureBoxesPath should always have a different first digit
                    if (direction != "Right" & direction != "Left" & direction != "Down" & direction != "Up")
                    {
                        while (x < pictureBoxesPath.Count)
                        {
                            if (x != 0) { PrevEdgeCheck = EdgeCheck; }
                            EdgeCheck = pictureBoxesPath[x];
                            EdgeCheck /= 10;  //because its stored as int the decimal just disappears
                            if (PrevEdgeCheck == EdgeCheck)
                            { loopsDone = 0; }
                            x += 1;

                        }

                    }
                    else if (direction == "Right" || direction == "Left")
                    {
                        while (x < pictureBoxesPath.Count)
                        {
                            if (x != 0) { PrevEdgeCheck = EdgeCheck; }
                            EdgeCheck = pictureBoxesPath[x];
                            EdgeCheck /= 10;  //because its stored as int the decimal just disappears
                            if (PrevEdgeCheck != EdgeCheck)
                            { loopsDone = 0; }
                            x += 1;

                        }
                    }
                    
                    
                    x = 0;
                    while (x < pictureBoxesPath.Count) //prevents pictureBoxesPath from containing a negative number
                    {
                        if (pictureBoxesPath[x] < 0)
                        {
                            loopsDone = 0;
                            x = pictureBoxesPath.Count;
                        }
                        else
                        { x += 1; }
                    }
                    x = 0;
                    while (x < pictureBoxesPath.Count) //the exact same as the code directly above but for preventing numbers above 99
                    {
                        if (pictureBoxesPath[x] > 99)
                        {
                            loopsDone = 0;
                            x = pictureBoxesPath.Count;
                        }
                        else
                        { x += 1; }
                    }
                    x = 0;


                    
                    if (Length > loopsDone)
                    {
                        DirectionsNotBanned.Remove(direction);
                        CountToNewDirection += 1;
                    }


                    x = 0;
                }
            x = 0;
            while (x < Length)
            {
                while (pictureBoxesPath.Count > 10) { pictureBoxesPath.RemoveAt(pictureBoxesPath.Count - 1); }

                pictureBoxList[pictureBoxesPath[x]].Load(ChoppedUpWord[x] + ".png");
                pictureBoxesLeft.Remove(pictureBoxesPath[x] );
                MessageBox.Show("ThisWay");

                
                x += 1;

            }
            x = 0;
            InputsLeft -= 1;
            InputsLoaded += 1;
            DirectionsNotBanned.Clear();
            while (x < 8)
            {
                DirectionsNotBanned.Add(DirectionList[x]);
                x += 1;
            }
            x = 0;


            }//while (InputsLeft > 0)
            InputList.Clear();
            textBox1.Clear();
    }


       

        private void Enter_Click(object sender, EventArgs e)
        {
            if (this.WordTextbox.Text != "")
            {
                Input = WordTextbox.Text;
                WordTextbox.Text = "";

                InputList.Add(Input.ToLower());
                if (textBox1.Text == "") { textBox1.Text = "Currently contained words:";  }
                textBox1.AppendText(Environment.NewLine + Input);
                InputsLeft += 1;

            }
            else
            {
                MessageBox.Show("its empty");
            }
        }

      
        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            if (textBox1.Text == "") { textBox1.Text = "Currently contained words:"; }
        }
        
    }
}
